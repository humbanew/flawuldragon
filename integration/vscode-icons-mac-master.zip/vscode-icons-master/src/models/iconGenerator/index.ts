export * from './iconGenerator';
